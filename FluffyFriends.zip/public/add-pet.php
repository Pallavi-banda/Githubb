<?php date_default_timezone_set('Asia/Kolkata');  $today_datetime = date('Y-m-d H:i:s');  $today_date = date('Y-m-d'); $today_time = date('H:i:s'); ?>

      <?php 


	$img1 = $_FILES['image']['name'];
	if($img1 != '')
	{
	$img1 = rand(1,1000000).str_replace(" ","_",trim($_FILES['image']['name']));
 	$tmp_name=$_FILES["image"]["tmp_name"];
	$pr="assets/images/";
	$pr1=$pr.$img1;
	move_uploaded_file($tmp_name,$pr1);
	}
	
	
  $sql=mysqli_query($con,"INSERT INTO `pets` (`name`, `type`, `status`, `age`, `description`, `image`, `created_at`, `contact`) VALUES ('".mysqli_real_escape_string($con,$_REQUEST['name'])."','".mysqli_real_escape_string($con,$_REQUEST['type'])."','available', '".mysqli_real_escape_string($con,$_REQUEST['age'])."', '".mysqli_real_escape_string($con,$_REQUEST['description'])."','$pr1', '$today_datetime', '".mysqli_real_escape_string($con,$_REQUEST['contact'])."')");	 
 	?>
    <script>alert('Added Successfully');</script>
      <script language="javascript">window.location.href="http://127.0.0.1/FluffyFriends/public/add-pet";</script>

