<?php
// public/index.php - front controller
require_once __DIR__ . '/../core/Database.php';


// Simple router
$path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$base = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/\\');
$uri = '/'. trim(substr($path, strlen($base)), '/');
if($uri === '' || $uri === '/'){
    require_once __DIR__ . '/../app/controllers/HomeController.php';
    $ctrl = new HomeController();
    $ctrl->index();
} elseif (preg_match('#^/pets(?:/(\w+))?#', $uri, $m)) {
    require_once __DIR__ . '/../app/controllers/PetsController.php';
    $ctrl = new PetsController();
    $type = $m[1] ?? 'all';
    $ctrl->list($type);
} elseif ($uri === '/about') {
    require_once __DIR__ . '/../app/controllers/HomeController.php';
    $ctrl = new HomeController();
    $ctrl->about();
} elseif ($uri === '/adopt') {
    require_once __DIR__ . '/../app/controllers/AdoptController.php';
    $ctrl = new AdoptController();
    if($_SERVER['REQUEST_METHOD'] === 'POST') $ctrl->submit();
    else $ctrl->form();
} elseif ($uri === '/contact') {
    require_once __DIR__ . '/../app/controllers/ContactController.php';
    $ctrl = new ContactController();
    if($_SERVER['REQUEST_METHOD'] === 'POST') $ctrl->submit();
    else $ctrl->form();
} elseif ($uri === '/add-pet') {
    require_once __DIR__ . '/../app/controllers/AddPetController.php';
    $c=new AddPetController(); if($_SERVER['REQUEST_METHOD']==='POST') $c->submit(); else $c->form();
} else {
    http_response_code(404);
    echo '404 - Page not found';
}
?>