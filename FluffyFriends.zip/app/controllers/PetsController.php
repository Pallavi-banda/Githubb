<?php
// app/controllers/PetsController.php
require_once __DIR__ . '/../models/Pet.php';
class PetsController {
    public function list($type='all') {
        $pets = Pet::getByType($type);
        require __DIR__ . '/../views/pets/list.php';
    }
}
?>