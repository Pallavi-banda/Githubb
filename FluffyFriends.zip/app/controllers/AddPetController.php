<?php
require_once __DIR__ . '/../models/Pet.php';
require_once __DIR__ . '/../../core/Database.php';

class AddPetController {
  public function form() {
    require_once __DIR__ . '/../views/addpet/form.php';
  }

  public function submit() {
    // Get DB (expecting a PDO instance)
    $db = Database::getInstance();

    // Ensure PDO throws exceptions (helps debugging)
    if ($db instanceof PDO) {
      $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }

    // collect & sanitize inputs (basic)
    $name = trim($_POST['name'] ?? '');
    $types = trim($_POST['type'] ?? '');
    $contact = trim($_POST['contact'] ?? '');
    $age = trim($_POST['age'] ?? '');
    $desc = trim($_POST['description'] ?? '');
    $imgPath = '';

    try {
      // Handle upload if present
      if (isset($_FILES['image']) && !empty($_FILES['image']['name'])) {
        $uploads = __DIR__ . '/../../assets/uploads';
        if (!is_dir($uploads)) {
          if (!mkdir($uploads, 0777, true) && !is_dir($uploads)) {
            throw new RuntimeException("Failed to create upload directory: $uploads");
          }
        }

        // basic validation: optional, add more (MIME, size)
        if ($_FILES['image']['error'] !== UPLOAD_ERR_OK) {
          throw new RuntimeException('Upload error code: ' . $_FILES['image']['error']);
        }

        $fname = time() . '_' . preg_replace('/[^A-Za-z0-9\-\_\.]/', '_', basename($_FILES['image']['name']));
        $target = $uploads . '/' . $fname;

        if (!move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
          throw new RuntimeException('Failed to move uploaded file to target location.');
        }

        // store web-accessible relative path
        $imgPath = 'assets/uploads/' . $fname;
      }

      // Use explicit backticks for column names (avoids reserved-word problems)
      $sql = "INSERT INTO `pets` (`name`, `types`, `age`, `description`, `image`, `contact`, `status`, `created_at`)
              VALUES (:name, :types, :age, :description, :image, :contact, :status, NOW())";

      $stmt = $db->prepare($sql);
      if ($stmt === false) {
        $err = $db->errorInfo();
        throw new RuntimeException("Failed to prepare statement: " . json_encode($err));
      }

      $params = [
        ':name' => $name,
        ':types' => $types,
        ':age' => $age,
        ':description' => $desc,
        ':image' => $imgPath,
        ':contact' => $contact,
        ':status' => 'available'
      ];

      $ok = $stmt->execute($params);

      if ($ok) {
        // success; redirect back (or to a success page)
        $ref = $_SERVER['HTTP_REFERER'] ?? '/';
        header("Location: {$ref}?success=1");
        exit;
      } else {
        $err = $stmt->errorInfo();
        throw new RuntimeException("Insert failed: " . json_encode($err));
      }
    } catch (Throwable $e) {
      // Log error and redirect with failure (avoid exposing DB errors to users in production)
      error_log("AddPetController::submit error: " . $e->getMessage());

      // For local dev you may want to see the error: uncomment the next line
      // echo '<pre>' . htmlspecialchars($e->getMessage()) . '</pre>';

      $ref = $_SERVER['HTTP_REFERER'] ?? '/';
      header("Location: {$ref}?success=0&err=" . urlencode($e->getMessage()));
      exit;
    }
  }
}
