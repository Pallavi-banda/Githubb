<?php
// app/controllers/ContactController.php
require_once __DIR__ . '/../models/Contact.php';
class ContactController {
    public function form() {
        require __DIR__ . '/../views/contact/contact_form.php';
    }
    public function submit() {
        $data = $_POST;
        $ok = Contact::create($data);
        if($ok) header('Location: /?contact=success');
        else header('Location: /?contact=fail');
    }
}
?>