<?php
// app/controllers/AdoptController.php
require_once __DIR__ . '/../models/Adopt.php';
require_once __DIR__ . '/../models/Pet.php';
class AdoptController {
    public function form() {
        $pet = null;
        if(!empty($_GET['pet_id'])) {
            $id = intval($_GET['pet_id']);
            $pet = Pet::getById($id);
        }
        require __DIR__ . '/../views/adopt/adopt_form.php';
    }
    public function submit() {
        $data = $_POST;
        $ok = Adopt::create($data);
        if($ok) header('Location: /?adopt=success');
        else header('Location: /?adopt=fail');
    }
}
?>