<?php
// FIXED: Ensure 'status' column exists in DB (pets table). If missing, run provided SQL to recreate DB.

// app/models/Pet.php
require_once __DIR__ . '/../../core/Database.php';
class Pet {
    public static function getFeatured() {
        $pdo = Database::getInstance();
        $stmt = $pdo->query("SELECT * FROM pets WHERE status='available' LIMIT 6");
        return $stmt->fetchAll();
    }
    public static function getByType($type='all') {
        $pdo = Database::getInstance();
        if(strtolower($type) === 'all' || empty($type)) {
            $stmt = $pdo->query("SELECT * FROM pets");
            return $stmt->fetchAll();
        }
        $stmt = $pdo->prepare("SELECT * FROM pets WHERE LOWER(type) = LOWER(?)");
        $stmt->execute([$type]);
        return $stmt->fetchAll();
    }
    public static function getById($id) {
        $pdo = Database::getInstance();
        $stmt = $pdo->prepare("SELECT * FROM pets WHERE id = ? LIMIT 1");
        $stmt->execute([$id]);
        return $stmt->fetch();
    }
}
?>
