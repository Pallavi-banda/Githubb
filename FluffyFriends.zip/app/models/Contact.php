<?php
// app/models/Contact.php
require_once __DIR__ . '/../../core/Database.php';
class Contact {
    public static function create($data) {
        $pdo = Database::getInstance();
        $stmt = $pdo->prepare("INSERT INTO contacts (name,email,subject,message,created_at) VALUES (?,?,?,?,NOW())");
        return $stmt->execute([
            $data['name'] ?? '',
            $data['email'] ?? '',
            $data['subject'] ?? '',
            $data['message'] ?? ''
        ]);
    }
}
?>