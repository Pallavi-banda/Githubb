<?php
// app/models/Adopt.php
require_once __DIR__ . '/../../core/Database.php';
class Adopt {
    public static function create($data) {
        $pdo = Database::getInstance();
        $stmt = $pdo->prepare("INSERT INTO adoptions (name,email,phone,pet_id,message,created_at) VALUES (?,?,?,?,?,NOW())");
        return $stmt->execute([
            $data['name'] ?? '',
            $data['email'] ?? '',
            $data['phone'] ?? '',
            $data['pet_id'] ?? 0,
            $data['message'] ?? ''
        ]);
    }
}
?>