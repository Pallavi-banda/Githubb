<?php require __DIR__ . '/../layouts/header.php'; ?>

<!-- Poppins Font -->
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">

<style>
  body {
    font-family: 'Poppins', sans-serif;
    background-color: #f8fafc;
    color: #1e293b;
  }

  .section-title {
    font-size: 2.5rem;
    font-weight: 700;
    text-align: center;
    margin-bottom: 2rem;
    color: #14b8a6;
    position: relative;
  }

  /* .section-title::after {
    content: '';
    display: block;
    width: 60px;
    height: 4px;
    background-color: #14b8a6;
    margin: 0.5rem auto 0;
    border-radius: 2px;
  } */

  .about-area {
    max-width: 1100px;
    margin: 0 auto;
    padding: 2rem 1rem;
  }

  .about-text {
    font-size: 1.05rem;
    color: #475569;
    line-height: 1.7;
  }

  .about-img {
    width: 100%;
    max-width: 350px;
    aspect-ratio: 1/1; /* square images */
    border-radius: 1rem;
    object-fit: cover;
    box-shadow: 0 10px 25px rgba(0,0,0,0.15);
    transition: transform 0.3s, box-shadow 0.3s;
  }

  .about-img:hover {
    transform: scale(1.05);
    box-shadow: 0 14px 30px rgba(0,0,0,0.25);
  }

  .cta-btn {
    display: inline-block;
    margin-top: 1.5rem;
    padding: 0.75rem 2rem;
    background-color: #14b8a6;
    color: #fff;
    font-weight: 600;
    border-radius: 30px;
    text-decoration: none;
    transition: background-color 0.3s, transform 0.2s;
  }

  .cta-btn:hover {
    background-color: #0d9488;
    transform: translateY(-2px);
  }

  .about-grid {
    display: grid;
    grid-template-columns: 1fr;
    gap: 2rem;
    align-items: center;
  }

  @media(min-width: 768px) {
    .about-grid {
      grid-template-columns: 1fr 1fr;
    }
  }

  .accent-box p{
    color: white;
  }
</style>

<!-- About Section -->
<section class="about-area soft-fade">
  <h1 class="section-title">About Fluffy Friends</h1>

  <div class="about-grid">
    <div class="about-text accent-box">
      <p>
        <strong>Fluffy Friends</strong> rescues, rehabilitates, and rehomes pets who are abandoned, neglected, or in need of care. 
        We provide medical attention, vaccinations, socialization, and love to ensure every pet is ready for a forever home.
      </p>
      <p>
        Our mission: <strong>Adopt · Care · Love.</strong> Every pet deserves a loving family, and every family deserves a loyal companion.
      </p>
      <a href="<?php echo $base; ?>/adopt" class="cta-btn">Adopt a Pet Today</a>
    </div>

    <div class="flex justify-center">
      <img src="https://tse1.explicit.bing.net/th/id/OIP.8C-s3lo2wm4TpcQM6K637AHaE1?cb=ucfimgc2&rs=1&pid=ImgDetMain&o=7&rm=3" 
           alt="Cute Pet" class="about-img">
    </div>
  </div>
</section>

<section class="about-area soft-fade mt-12">
  <div class="about-grid">
    <div class="flex justify-center">
      <img src="https://images.rawpixel.com/image_800/cHJpdmF0ZS9sci9pbWFnZXMvd2Vic2l0ZS8yMDI0LTAzL2ZyZWVpbWFnZXNjb21wYW55X3Bob3RvX29mX2Ffd29tYW5faG9sZGluZ19hX3B1cHB5X2NhbmRpZF9waG90b182ZGZiMTIyZC1lN2MwLTQyMjItYjM4OS1iYzVjZmJhNmZiODZfMS5qcGc.jpg" 
           alt="Happy Dog" class="about-img">
    </div>
    <div class="about-text accent-box">
      <p>
        We are a community-driven pet adoption center connecting loving families with perfect companions. 
        Our volunteers ensure each pet is healthy, happy, and ready to join a new home.
      </p>
      <p>
        Join our family of pet lovers and make a difference — one adoption at a time.
      </p>
      <a href="<?php echo $base; ?>/contact" class="cta-btn">Contact Us</a>
    </div>
  </div>
</section>

<?php require __DIR__ . '/../layouts/footer.php'; ?>
