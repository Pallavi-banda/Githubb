<?php require __DIR__ . '/../layouts/header.php'; ?>
<!-- Add this in your <head> section (header.php) -->
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">


<style>
  /* GLOBAL FONT & COLORS */
body{
  font-family: 'Poppins', sans-serif;
}

  .section-title{
    font-size: 2.4rem;
    font-weight: 800;
    color: #ffffff;
    text-align: center;
    margin-bottom: 1.5rem;
  }

  .text-muted{
    color: #e5e7eb;
    font-size: 1.05rem;
    line-height: 1.7;
  }

  /* HERO SECTION */
  .hero-area{
    color: white;
    margin-top: 30px;
  }
  .hero-area .hero-img{
    width: 370px;
    height: 370px;
    border-radius: 20px;
    object-fit: cover;
    box-shadow: 0 15px 40px rgba(0,0,0,0.25);
  }

  /* BUTTONS */
  .primary-btn{
    background: #14b8a6;
    color: #FFFFFF;
    padding: 12px 24px;
    border-radius: 30px;
    font-weight: 700;
    display: inline-block;
    margin-top: 18px;
    transition: .3s;
  }
  .primary-btn:hover{
    background: #e2e8f0;
    color: #000;
  }

  /* ABOUT SECTION */
  .about-area{
    margin-top: 90px;
    padding: 80px 0;
    background: #0f172a;
    border-radius: 20px;
  }
  .about-img{
    width: 360px;
    height: 260px;
    border-radius: 16px;
    object-fit: cover;
    box-shadow: 0 10px 30px rgba(0,0,0,0.3);
  }

  /* PET CARD */
  .pet-card{
    background:#ffffff;
    border-radius:18px;
    padding:18px;
    transition:.35s;
    border:1px solid #e2e8f0;
  }
  .pet-card:hover{
    transform:translateY(-6px);
    box-shadow:0 14px 32px rgba(0,0,0,.12);
  }
  .pet-img{
    border-radius:16px;
    width:100%;
    height:200px;
    object-fit:cover;
  }

  .peach-btn{
    background:#ef4444;
    color:white;
    padding:7px 18px;
    border-radius:25px;
    font-size:14px;
    transition:.3s;
  }
  .peach-btn:hover{
    background:#dc2626;
  }
</style>


<!-- HERO SECTION -->
<section class="hero-area">
  <div class="grid grid-cols-1 md:grid-cols-2 gap-12 items-center px-10">
    
    <div>
      <h1 class="text-5xl font-extrabold leading-tight">Adopt Love. Give Home.</h1>
      <p class="text-white/90 mt-4 text-lg">Every pet deserves happiness. Give them a home full of love and care.</p>
      <a href="<?php echo $base; ?>/pets" class="primary-btn">Explore Pets</a>
    </div>

    <div class="flex justify-center">
      <img src="<?php echo $base; ?>/assets/images/pet_sample.jpg" class="hero-img">
    </div>

  </div>
</section>


<!-- ABOUT SECTION -->
<section class="about-area">
  <h2 class="section-title">Who We Are</h2>

  <div class="grid grid-cols-1 md:grid-cols-2 gap-12 px-10">
    
    <div class="text-muted">
      We are a non-profit pet rescue and adoption community. Our mission is to
      provide a safe and caring environment for stray, abandoned, and injured animals.
      <br><br>
      Every pet entering our shelter receives medical care, proper nutrition, hygiene,
      vaccinations, and emotional comfort. We work to find them loving families where
      they can live happy lives full of care and affection.
      <br><br>
      Your adoption not only gives a pet a new home, but it also opens space and hope
      for saving another life.
    </div>

    <div class="flex justify-center">
      <img src="<?php echo $base; ?>/assets/images/rescue_pets.jpg" class="about-img" alt="About Our Shelter">
    </div>

  </div>
</section>



<!-- PET LIST -->
<section class="mt-20 px-10">
  <h2 class="section-title" style="color:#ffffff;">Available Pets</h2>

  <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-7">

    <?php foreach($pets as $p): ?>
      <div class="pet-card">
        <img src="<?php echo $base; ?>/assets/images/pet_sample.jpg" class="pet-img" alt="<?=htmlspecialchars($p['name'])?>">
        <h3 class="mt-4 font-bold text-xl text-slate-800"><?=htmlspecialchars($p['name'])?></h3>
        <p class="text-muted text-sm" style="color:#475569;">
          <?=htmlspecialchars($p['type'])?> · <?=htmlspecialchars($p['age'])?> years old
        </p>

        <div class="mt-5 flex justify-between items-center">
          <a href="<?php echo $base; ?>/pets/<?=htmlspecialchars($p['type'])?>" class="text-sm text-indigo-600 font-medium hover:underline">View Details</a>
          <a href="<?php echo $base; ?>/adopt?pet_id=<?=intval($p['id'])?>" class="peach-btn">Adopt</a>
        </div>
      </div>
    <?php endforeach; ?>

  </div>
</section>


<!-- CONTACT -->
<section class="mt-20 text-center mb-20">
  <h2 class="section-title" style="color:#ffffff;">Need Guidance?</h2>
  <p class="text-muted" style="color:#475569;">Our team will help you choose the right pet.</p>
  <a href="<?php echo $base; ?>/contact" class="primary-btn" style="background:#0d9488; color:white;">Contact Us</a>
</section>

<?php require __DIR__ . '/../layouts/footer.php'; ?>
