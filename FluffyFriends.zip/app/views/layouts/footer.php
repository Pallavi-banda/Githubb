</main>

<footer class="footer-area mt-20 text-white">
  <style>
    .footer-area{
      background: linear-gradient(135deg, #14b8a6, #0d9488);
      padding: 60px 0;
      border-top-left-radius: 40px;
      border-top-right-radius: 40px;
    }
    .footer-title{
      font-size: 1.5rem;
      font-weight: 700;
      margin-bottom: 12px;
      color: #ffffff;
    }
    .footer-text{
      color: #d1fae5;
      font-size: 14px;
      line-height: 1.7;
    }
    .footer-links a{
      color: #d1fae5;
      transition: .25s;
    }
    .footer-links a:hover{
      color: #ffffff;
      padding-left: 4px;
    }

    /* SOCIAL ICONS */
    .footer-social a{
      width: 42px;
      height: 42px;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      border-radius: 50%;
      background: rgba(255,255,255,0.9);
      margin-right: 10px;
      transition: .3s;
    }
    .footer-social a:hover{
      transform: translateY(-5px) scale(1.07);
      box-shadow: 0 10px 20px rgba(0,0,0,0.25);
    }

    /* BOTTOM COPYRIGHT */
    .footer-bottom{
      border-top:1px solid rgba(255,255,255,0.35);
      margin-top: 40px;
      padding-top: 18px;
      font-size: 14px;
      text-align:center;
      color:#e6fffa;
    }
  </style>

  <div class="max-w-6xl mx-auto px-6 grid grid-cols-1 md:grid-cols-3 gap-10">

    <!-- Brand -->
    <div>
      <div class="footer-title">Fluffy Friends</div>
      <p class="footer-text">
        We help rescued pets find warm, loving homes.
        Adopt compassion. Adopt happiness.
      </p>
    </div>

    <!-- Quick Links -->
    <div>
      <div class="footer-title">Quick Links</div>
      <ul class="footer-text footer-links space-y-1">
        <li><a href="<?php echo $base; ?>/adopt">Adopt a Pet</a></li>
        <li><a href="<?php echo $base; ?>/pets">All Pets</a></li>
        <li><a href="<?php echo $base; ?>/about">About Us</a></li>
        <li><a href="<?php echo $base; ?>/contact">Contact</a></li>
      </ul>
    </div>

    <!-- Social -->
   <div>
  <div class="footer-title">Connect With Us</div>

  <div class="footer-social flex gap-4 items-center mt-2">

    <!-- WhatsApp -->
    
    Address : Ahmedabad, Gujarat, India.<br />

    Contact No : +91 6355 574 334
<br />
    Email ID : arpitapanchal2005@gmail.com

  </div>
</div>


  </div>

  <div class="footer-bottom">
    © <?=date("Y")?> Fluffy Friends — Made with love for animals.
  </div>
</footer>

</body>
</html>
