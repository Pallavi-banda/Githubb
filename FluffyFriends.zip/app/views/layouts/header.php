<?php
// Compute base path
$base = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/\\');
if ($base === '') $base = '/';
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Fluffy Friends</title>

<script src="https://cdn.tailwindcss.com"></script>

<style>
:root {
  --bg:#0f172a;
  --card:#111a2c;
  --text:#e2e8f0;
  --muted:#94a3b8;
  --primary:#14b8a6; /* Teal */
  --primary-dark:#0d9488;
  --accent:#ff809a;
}

/* Fade animation */
.soft-fade { animation: mfade .4s ease both; }
@keyframes mfade { 
  from { opacity:0; transform:translateY(8px) } 
  to { opacity:1; transform:none } 
}

/* Navigation Hover Line */
.nav-link {
  position: relative;
  transition: color .3s ease;
}
.nav-link::after {
  content: "";
  position: absolute;
  left: 0; bottom: -4px;
  width: 0%;
  height: 2px;
  background: var(--primary);
  transition: width .3s;
}
.nav-link:hover {
  color: var(--primary);
}
.nav-link:hover::after {
  width: 100%;
}

/* Active link highlight */
.nav-active {
  color: var(--primary);
}
.nav-active::after {
  width: 100%;
}

/* Glass Header */
.header-glass {
  background: rgba(15,23,42,.55);
  backdrop-filter: blur(18px);
  border-bottom: 1px solid rgba(255,255,255,.08);
}

/* Logo Glow */
.logo-icon {
  box-shadow: 0 0 22px rgba(20,184,166,.6);
}

/* Dropdown Smooth */
.group:hover .menu-drop {
  opacity: 1;
  transform: translateY(6px);
}
.menu-drop {
  opacity: 0;
  transform: translateY(12px);
  transition: .25s cubic-bezier(.2,.9,.2,1);
}

/* Ensure form inputs are visible on both dark and light backgrounds */
input, textarea, select, .form-control {
  color: var(--text) !important;
  background: transparent;
  border-radius: .5rem;
}
input::placeholder, textarea::placeholder {
  color: rgba(226,232,240,0.6);
}

/* Override for light input text */
input, textarea, select {
  color: #000 !important;
}
::placeholder {
  color: transparent !important;
}
</style>

</head>
<body class="bg-[var(--bg)] text-[var(--text)]">

<header class="header-glass sticky top-0 z-50 soft-fade">
  <div class="max-w-6xl mx-auto flex justify-between items-center px-6 py-4">

    <!-- Logo -->
    <a href="<?php echo $base; ?>/" class="flex items-center gap-3">
      <div class="w-12 h-12 rounded-full bg-[var(--primary)] flex items-center justify-center logo-icon">
        <svg width="800px" height="800px" viewBox="-1.5 0 19 19" xmlns="http://www.w3.org/2000/svg" fill="#FFFFFF" class="cf-icon-svg">
          <path d="M4.086 7.9a1.91 1.91 0 0 1-.763 2.52c-.81.285-1.782-.384-2.17-1.492a1.91 1.91 0 0 1 .762-2.521c.81-.285 1.782.384 2.171 1.492zm6.521 7.878a2.683 2.683 0 0 1-1.903-.788.996.996 0 0 0-1.408 0 2.692 2.692 0 0 1-3.807-3.807 6.377 6.377 0 0 1 9.022 0 2.692 2.692 0 0 1-1.904 4.595zM7.73 6.057c.127 1.337-.563 2.496-1.54 2.588-.977.092-1.872-.917-1.998-2.254-.127-1.336.563-2.495 1.54-2.587.977-.093 1.871.916 1.998 2.253zm.54 0c-.127 1.337.563 2.496 1.54 2.588.977.092 1.871-.917 1.998-2.254.127-1.336-.563-2.495-1.54-2.587-.977-.093-1.872.916-1.998 2.253zm3.644 1.842a1.91 1.91 0 0 0 .763 2.522c.81.284 1.782-.385 2.17-1.493a1.91 1.91 0 0 0-.762-2.521c-.81-.285-1.782.384-2.171 1.492z"/>
        </svg>
      </div>
      <div>
        <div class="text-lg font-semibold tracking-wide">Fluffy Friends</div>
        <div class="text-xs text-[var(--muted)] -mt-1">Adopt · Care · Love</div>
      </div>
    </a>

    <!-- Desktop Nav -->
    <nav class="hidden md:flex items-center gap-8 text-sm">
      <a href="<?php echo $base; ?>/" 
         class="nav-link <?php echo ($_SERVER['REQUEST_URI'] == $base.'/') ? 'nav-active' : ''; ?>">Home</a>

      <a href="<?php echo $base; ?>/about" 
         class="nav-link <?php echo strpos($_SERVER['REQUEST_URI'], '/about') !== false ? 'nav-active' : ''; ?>">About</a>

      <!-- Pets Dropdown -->
      <div class="group relative">
        <a href="<?php echo $base; ?>/pets" class="nav-link <?php echo strpos($_SERVER['REQUEST_URI'], '/pets') !== false ? 'nav-active' : ''; ?>">Pets ▾</a>
        <div class="menu-drop absolute left-0 mt-3 p-3 rounded shadow-md" style="min-width:140px; background:var(--card); color:var(--text);">
          <a href="<?php echo $base; ?>/pets?type=dog" class="block py-1 px-2 hover:underline">Dog</a>
          <a href="<?php echo $base; ?>/pets?type=cat" class="block py-1 px-2 hover:underline">Cat</a>
          <a href="<?php echo $base; ?>/pets?type=rabbit" class="block py-1 px-2 hover:underline">Rabbit</a>
          <a href="<?php echo $base; ?>/pets?type=bird" class="block py-1 px-2 hover:underline">Bird</a>
        </div>
      </div>

      <a href="<?php echo $base; ?>/add-pet" 
         class="nav-link <?php echo strpos($_SERVER['REQUEST_URI'], '/add-pet') !== false ? 'nav-active' : ''; ?>">
         + Add Pet
      </a>

      <a href="<?php echo $base; ?>/adopt" 
         class="nav-link <?php echo strpos($_SERVER['REQUEST_URI'], '/adopt') !== false ? 'nav-active' : ''; ?>">Adopt Me</a>

      <a href="<?php echo $base; ?>/contact" 
         class="nav-link <?php echo strpos($_SERVER['REQUEST_URI'], '/contact') !== false ? 'nav-active' : ''; ?>">Contact</a>
    </nav>

    <!-- Mobile Button -->
    <div class="md:hidden">
      <a href="<?php echo $base; ?>/adopt" class="px-4 py-2 rounded-full bg-[var(--primary)] text-sm font-medium shadow">
        Adopt
      </a>
    </div>

  </div>
</header>

<main class="max-w-6xl mx-auto p-6">
<!-- Page content starts here -->
