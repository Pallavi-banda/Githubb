<?php require __DIR__ . '/../layouts/header.php'; ?>

<section class="max-w-3xl mx-auto p-6 soft-fade">
  <h2 class="text-3xl font-bold mb-6" style="color: #0d9488;">Adoption Request</h2>

  <?php if(isset($pet) && $pet): ?>
    <div class="mb-4 p-4 border rounded flex items-center gap-4">
      <?php if(!empty($pet['image'])): ?>
        <img src="<?php echo $base . '/' . $pet['image']; ?>" alt="<?php echo htmlspecialchars($pet['name']); ?>" style="width:120px;height:120px;object-fit:cover;border-radius:8px;">
      <?php endif; ?>
      <div>
        <h3 class="text-xl font-semibold"><?php echo htmlspecialchars($pet['name']); ?></h3>
        <p class="text-sm">Type: <?php echo htmlspecialchars($pet['type']); ?></p>
        <p class="text-sm"><?php echo htmlspecialchars($pet['description']); ?></p>
      </div>
    </div>
  <?php endif; ?>

  <form method="post" action="http://127.0.0.1/Fluffy_Friends/adopt-mail.php">
    <input type="hidden" name="pet_id" value="<?php echo isset($pet['id']) ? intval($pets['id']) : 0; ?>">
    <div class="mb-3">
      <label class="block mb-1">Your Name</label>
      <input name="name" required class="w-full p-2 rounded-lg border" />
    </div>
    <div class="mb-3">
      <label class="block mb-1">Email</label>
      <input name="email" type="email" required class="w-full p-2 rounded-lg border" />
    </div>
    <div class="mb-3">
      <label class="block mb-1">Phone</label>
      <input name="phone" required class="w-full p-2 rounded-lg border" />
    </div>
    <div class="mb-3">
      <label class="block mb-1">Message</label>
      <textarea name="message" class="w-full p-2 rounded-lg border"></textarea>
    </div>

    <div class="text-center">
      <button type="submit" class="px-8 py-3 bg-[#0d9488] text-white rounded-full shadow-lg hover:bg-[#0b7a72] transition">Submit</button>
    </div>
  </form>
</section>

<?php require __DIR__.'/../layouts/footer.php'; ?>
