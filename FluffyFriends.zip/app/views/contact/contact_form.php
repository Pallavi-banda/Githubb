<?php require __DIR__ . '/../layouts/header.php'; ?>

<!-- Poppins Font -->
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">

<style>
  body {
    font-family: 'Poppins', sans-serif;
  }
</style>

<div class="soft-fade max-w-3xl mx-auto px-4 py-8">
  <h1 class="text-4xl font-bold text-center mb-8" style="color: #0d9488;">Contact Us</h1>

  <form action="http://127.0.0.1/Fluffy_Friends/contact-mail.php" method="post" class="bg-white rounded-2xl shadow-lg p-8 space-y-6">

    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
      <div>
        <label class="block text-sm font-medium text-gray-700 mb-1">Full Name</label>
        <input name="name" required 
               class="w-full p-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-[#0d9488] focus:border-[#0d9488] transition" />
      </div>
      <div>
        <label class="block text-sm font-medium text-gray-700 mb-1">Email</label>
        <input name="email" type="email" required 
               class="w-full p-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-[#0d9488] focus:border-[#0d9488] transition" />
      </div>
    </div>

    <div>
      <label class="block text-sm font-medium text-gray-700 mb-1">Subject</label>
      <input name="subject" 
             class="w-full p-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-[#0d9488] focus:border-[#0d9488] transition" />
    </div>

    <div>
      <label class="block text-sm font-medium text-gray-700 mb-1">Message</label>
      <textarea name="message" rows="4" 
                class="w-full p-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-[#0d9488] focus:border-[#0d9488] transition"></textarea>
    </div>

    <div class="text-center">
      <button type="submit" 
              class="px-8 py-3 bg-[#0d9488] text-white font-semibold rounded-full shadow-lg hover:bg-[#0b7a72] hover:shadow-xl transition">
        Send Message
      </button>
    </div>

  </form>
</div>

<?php require __DIR__ . '/../layouts/footer.php'; ?>
