<?php require __DIR__.'/../layouts/header.php'; ?>

<!-- Poppins Font -->
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">

<style>
  body {
    font-family: 'Poppins', sans-serif;
  }
</style>

<section class="max-w-3xl mx-auto p-6 soft-fade">
  <h2 class="text-3xl font-bold mb-6" style="color: #0d9488;">Add a Pet for Adoption</h2>

  <?php if(!empty($_GET['success'])): ?>
    <div class="bg-green-100 text-green-800 p-3 rounded mb-4">Pet added successfully!</div>
  <?php endif; ?>

  <form method="POST" enctype="multipart/form-data" action="<?php echo $base; ?>/add-pet.php" class="bg-white p-8 rounded-2xl shadow-lg space-y-6">

    <div>
      <label class="block text-sm font-medium text-gray-700 mb-1">Pet Name</label>
      <input name="name" required
             class="w-full p-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-[#0d9488] focus:border-[#0d9488] transition" />
    </div>

    
    <div class="mb-3">
      <label class="block text-sm font-medium text-gray-700 mb-1">Type</label>
      <select name="type" id="pet-type" required class="w-full p-2 rounded-lg border">
        <option value="">Select Type</option>
        <option value="dog">Dog</option>
        <option value="cat">Cat</option>
        <option value="rabbit">Rabbit</option>
        <option value="bird">Bird</option>
      </select>
    </div>

    <!-- <div class="mb-3">
      <label class="block mb-1">Breed</label>
      <select name="breed" id="pet-breed" required class="w-full p-2 rounded-lg border">
        <option value="">Select Breed</option>
      </select>
    </div> -->

    <script>
      (function(){
        const breeds = {
          dog: ['Golden Retriever','Labrador','Beagle','Bulldog','Pomeranian','Mixed'],
          cat: ['Persian','Siamese','Maine Coon','Bengal','Domestic Shorthair','Mixed'],
          rabbit: ['Dutch','Lionhead','Netherland Dwarf','Flemish Giant','English Lop','Mixed'],
          bird: ['Parakeet','Canary','Cockatiel','Lovebird','Finch','Mixed']
        };
        const typeEl = document.getElementById('pet-type');
        const breedEl = document.getElementById('pet-breed');
        function populateBreed(type){
          breedEl.innerHTML = '<option value="">Select Breed</option>';
          if(!type || !breeds[type]) return;
          breeds[type].forEach(b => {
            const opt = document.createElement('option');
            opt.value = b;
            opt.textContent = b;
            breedEl.appendChild(opt);
          });
        }
        typeEl.addEventListener('change', function(){ populateBreed(this.value); });
        // if editing or prefilled value exists, attempt to set it
        window.addEventListener('DOMContentLoaded', function(){
          const selType = typeEl.getAttribute('data-selected');
          const selBreed = breedEl.getAttribute('data-selected');
          if(selType) { typeEl.value = selType; populateBreed(selType); if(selBreed) breedEl.value = selBreed; }
        });
      })();
    </script>


    <div>
      <label class="block text-sm font-medium text-gray-700 mb-1">Age</label>
      <input name="age"
             class="w-full p-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-[#0d9488] focus:border-[#0d9488] transition" />
    </div>

    <div>
      <label class="block text-sm font-medium text-gray-700 mb-1">Owner Contact</label>
      <input name="contact" required
             class="w-full p-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-[#0d9488] focus:border-[#0d9488] transition" />
    </div>

    <div>
      <label class="block text-sm font-medium text-gray-700 mb-1">Description</label>
      <textarea name="description" rows="4" 
                class="w-full p-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-[#0d9488] focus:border-[#0d9488] transition"></textarea>
    </div>

    <div>
      <label class="block text-sm font-medium text-gray-700 mb-1">Pet Image</label>
      <input type="file" name="image" accept="image/*" required
             class="w-full p-2 rounded-lg border border-gray-300 focus:ring-2 focus:ring-[#0d9488] focus:border-[#0d9488] transition" />
    </div>

    <div class="text-center">
      <button type="submit"
              class="px-8 py-3 bg-[#0d9488] text-white font-semibold rounded-full shadow-lg hover:bg-[#0b7a72] hover:shadow-xl transition">
        Submit
      </button>
    </div>

  </form>
</section>

<?php require __DIR__.'/../layouts/footer.php'; ?>
