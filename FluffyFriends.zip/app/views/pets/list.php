<?php require __DIR__ . '/../layouts/header.php'; ?>

<!-- Poppins Font -->
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">

<style>
  body {
    font-family: 'Poppins', sans-serif;
    background-color: #f8fafc;
    color: #1e293b;
    margin: 0;
    padding: 0;
  }

  .page-title {
    font-size: 2.5rem;
    font-weight: 700;
    text-align: center;
    margin: 2rem 0;
    color: #14b8a6;
  }

  .pet-categories {
    display: flex;
    gap: 0.75rem;
    justify-content: center;
    flex-wrap: wrap;
    margin-bottom: 3rem;
  }

  .pet-categories a {
    padding: 0.5rem 1.5rem;
    border-radius: 25px;
    font-weight: 500;
    text-decoration: none;
    color: #1e293b;
    background-color: #e2e8f0;
    transition: all 0.3s;
  }

  .pet-categories a.active {
    background-color: #14b8a6;
    color: #fff;
    transform: translateY(-2px);
    box-shadow: 0 6px 16px rgba(0,0,0,0.12);
  }

  .pet-categories a:hover:not(.active) {
    background-color: #cbd5e1;
  }

  .pet-grid {
    display: grid;
    grid-template-columns: 1fr;
    gap: 2rem;
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 1rem;
  }

  @media(min-width: 640px) {
    .pet-grid {
      grid-template-columns: repeat(2, 1fr);
    }
  }

  @media(min-width: 1024px) {
    .pet-grid {
      grid-template-columns: repeat(3, 1fr);
    }
  }

  .pet-card {
    background-color: #ffffff;
    border-radius: 1.5rem;
    overflow: hidden;
    transition: transform 0.35s, box-shadow 0.35s;
    border: 1px solid #e2e8f0;
    position: relative;
  }

  .pet-card:hover {
    transform: translateY(-8px);
    box-shadow: 0 16px 32px rgba(0,0,0,0.15);
  }

  .pet-card img {
    width: 100%;
    height: 250px;
    object-fit: cover;
    border-radius: 1.5rem 1.5rem 0 0;
  }

  .pet-card-content {
    padding: 1rem 1.25rem;
  }

  .pet-card-content h3 {
    font-size: 1.25rem;
    font-weight: 700;
    margin-bottom: 0.25rem;
    color: #1e293b;
  }

  .pet-card-content p {
    font-size: 0.95rem;
    color: #64748b;
    margin-bottom: 0.5rem;
  }

  .adopt-btn {
    background-color: #14b8a6;
    color: #fff;
    padding: 0.5rem 1.5rem;
    border-radius: 25px;
    font-weight: 500;
    text-decoration: none;
    display: inline-block;
    transition: all 0.3s;
  }

  .adopt-btn:hover {
    background-color: #0d9488;
    transform: translateY(-2px);
  }

  .soft-fade {
    animation: fadeIn 0.7s ease forwards;
  }

  @keyframes fadeIn {
    from { opacity: 0; transform: translateY(10px); }
    to { opacity: 1; transform: translateY(0); }
  }
</style>

<?php
  // Determine pet type from URL, default to 'dog'
  $type = strtolower($_GET['type'] ?? 'dog');
  $valid_types = ['dog', 'cat', 'rabbit', 'bird'];

  if (!in_array($type, $valid_types)) {
      $type = 'dog';
  }

  // Filter pets by type safely
  $filtered_pets = array_filter($pets ?? [], function($p) use ($type) {
      return strtolower($p['type'] ?? '') === $type;
  });
?>

<section class="soft-fade">
  <h1 class="page-title">Our <?= ucfirst($type) ?>s</h1>

  <!-- Category Tabs -->
  <div class="pet-categories">
    <?php foreach ($valid_types as $t): ?>
      <a href="<?= $base; ?>/pets?type=<?= $t ?>" class="<?= ($t === $type) ? 'active' : '' ?>">
        <?= ucfirst($t) ?>
      </a>
    <?php endforeach; ?>
  </div>

  <!-- Pet Grid -->
  <div class="pet-grid">
    <?php if (empty($filtered_pets)): ?>
      <div class="col-span-full text-center text-gray-500">
        No <?= $type ?>s available right now.
      </div>
    <?php else: ?>
    
      <?php foreach ($filtered_pets as $p): 
        $img = trim($p['image'] ?? '');
        /*if (!$img) {
          $img = 'https://images.unsplash.com/photo-1558788353-f76d92427f16?crop=entropy&cs=tinysrgb&fit=crop&h=350&w=350';
        } elseif (!preg_match("#^https?://#", $img)) {
          $img = $base . '/' . ltrim($img, '/');
        }*/
      ?>
        <div class="pet-card">
          <img src="<?php echo $base; ?>/<?= htmlspecialchars($img) ?>" alt="<?= htmlspecialchars($p['name'] ?? 'Pet') ?>">
          <div class="pet-card-content">
            <h3><?= htmlspecialchars($p['name'] ?? 'Unknown') ?></h3>
            <p><?= htmlspecialchars($p['type'] ?? 'Unknown') ?> · <?= htmlspecialchars($p['age'] ?? 'N/A') ?> years old</p>
            <p><?= htmlspecialchars(substr($p['description'] ?? '', 0, 100)) ?>...</p>
            <a href="<?= $base; ?>/adopt?pet_id=<?= intval($p['id'] ?? 0) ?>" class="adopt-btn">Adopt</a>
          </div>
        </div>
      <?php endforeach; ?>
    <?php endif; ?>
  </div>
</section>

<?php require __DIR__ . '/../layouts/footer.php'; ?>
