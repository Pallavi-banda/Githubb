<?php
if($_SERVER["REMOTE_ADDR"]=="127.0.0.1")
{
$con = mysqli_connect('localhost', 'root', '', 'es_inquirysoft');
}
else
{
$con = mysqli_connect('localhost', 'u287345123_Fluffy_Friends', 'Dbuser@123', 'u287345123_Fluffy_Friends');
}
?>